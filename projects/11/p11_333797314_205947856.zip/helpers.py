def indent(s):
    return ''.join('  ' + line for line in s.splitlines(True))